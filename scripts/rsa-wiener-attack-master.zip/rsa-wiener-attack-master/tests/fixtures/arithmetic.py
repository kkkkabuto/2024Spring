# [(number, expected_sqrt), ...]
# Sqrt is negative one if number is not a perfect square
TEST_NUM_SQRT = [
    (4, 2),
    (0, 0),
    (15, -1),
    (25, 5),
    (18, -1),
    (901, -1),
    (1000, -1),
    (1024, 32),
]